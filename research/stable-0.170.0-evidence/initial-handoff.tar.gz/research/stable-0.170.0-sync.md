# Stable 0.170.0 update: incomplete

Not ready to install. No builds, tests, lint, formatting, fixture generation, installation or publication were performed.

Verified the official release API: rust-v0.170.0 is neither draft nor prerelease, published 2026-11-18 03:40:48 UTC. Fetched the tag from upstream (openai/codex). Starting worktree was clean at 3431a3e7bb on chore/update-stable-0-170. Old source tip is preserved at backup/local13-before-0.170.0.

Read AGENTS.md and the previous stable update report. Home has approximately 2 GB free and scratch 424 GB. Global Cargo configuration sends build output to /scratch/agent/cache/cargo-build/{workspace-path-hash}, with kache enabled. Open-file soft limit is 524288. No subagents or live probes were used.

Attempted the 111-commit rebase onto rust-v0.170.0. The first conflict involved appended history tests. The next involved accepted-usage accounting across four files (see first-conflicts.txt). A trial net three-way composition exposed additional overlapping history/session changes; it was not accepted. Aborted the rebase and restored the entire original patch series. There is no active rebase.

Upstream now tracks last_server_reported_usage_item_count and last_model_output_item_count. This overlaps the local accepted-usage repair, but equivalence is unproven. Preserve local behavior until causal regression tests establish equivalence. Upstream also changes session injection, task admission and unified exec; the required background_exec_completion_starts_a_follow_up_turn_without_polling regression remains mandatory. Upstream toolchain specifies 1.95.0, whereas the local old tree specifies 1.99.1; toolchain and V8 selection remain unvalidated.

Remaining: review each patch for equivalence, resolve the rebase, align manifests to 0.170.0+local.14, build CLI and host early on scratch, run focused tests, regenerate fixtures, format and lint, freeze and run the authorized complete workspace suite, then verify final binaries. Coordinator owns integration, installation and publication. No environmental blocker has been established; this is incomplete work.

Cleanup: no build artifacts were created; original binaries and source were preserved. Scratch trial merge files were deleted after preserving the release response in this evidence directory. Final observed free disk: home 2.0 GB, scratch 424 GB.
